package com.vokasi.listview;

import java.io.Serializable;

/**
 * Created by praktikan on 3/24/2016.
 */
public class ItemData implements Serializable {
    public String itemTitle;
    public String itemDate;
    public String itemImage;
    public String itemLink;
    public String itemDesc;
}
